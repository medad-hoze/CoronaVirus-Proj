Esri welcomes contributions from anyone and everyone. Please see our [guidelines for contributing](https://github.com/esri/contributing).

## release instructions for maintainers

1. bump `package.json` version number
2. update CHANGELOG.md
3. run `npm run release`
