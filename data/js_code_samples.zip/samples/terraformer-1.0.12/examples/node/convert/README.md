# convert geojson, wkt, and arcgis geoservices files

## Installation

```
$ npm install
```

## Example Usage

```
$ node convert.js input.geojson output.json --in-format geojson --out-format arcgis
```