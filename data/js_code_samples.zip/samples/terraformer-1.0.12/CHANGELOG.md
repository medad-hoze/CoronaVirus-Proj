# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [unreleased]

## [1.0.12] - 2020-04-07

### Fixed

* added two missing variable declarations

### Changes

* `"strict mode"`

## [1.0.10] - 2020-01-07

### Changed

* TypeScript typings updates
* Updated internal dependencies to resolve security vulnerabilities

## [1.0.9] - 2018-06-08

### Changed

* moved from phantomjs to chrome for browser testing
* moved GeoJSON typings to `optionalDependencies` for TypeScript users.

### Removed

* doing a better job of purging extraneous files from the npm tarball.

## [1.0.8] - 2017-04-24

### Changed
* removed `.sass-cache` and another local debugging file from npm package

## [1.0.7] - 2016-10-17

### Fixed
* ensure that contains()/within() can compare the geometry of GeoJSON feature objects. [#281](https://github.com/Esri/Terraformer/issues/281)

### Removed
* the minified library and archived versions have been removed from source control

## [1.0.6] - 2016-08-17

### Added
* typings for TypeScript folks (thx [@JeffJacobson](https://github.com/JeffJacobson)) [#20](https://github.com/Esri/terraformer-wkt-parser/pull/20)
* lots of little website improvements

## [1.0.5] - 2015-03-14

### Changed

* Use Jarvis March for convex hulls

## [1.0.4] - 2014-08-06

### Fixed

* Internal improvements to `addVertex()` and `arrayIntersectsArrays`

### Added

* new `isConvex()` method

## [1.0.3] - 2014-02-24

### Fixed

* MultiPolygons can now be closed with the `multipolygon.close()` method.
* Circles are now closed properly [#234](https://github.com/Esri/Terraformer/pull/234)

## [1.0.2] - 2013-12-16

This release fixes several issues related to convexHull and ensures the Polygons are closed under a variety of situations.

### Breaking Changes

primitive.convexHull() now always returns null or a valid Terraformer.Polygon. It will not return arrays or throw errors.

### Fixed

* `Terraformer.Circle` is now closed.
* `Polygon`s returned by `primitive.convexHull()` are now closed.

### Added

* `primitive.convexHull()`` will now handle features.

## [1.0.1] - 2013-11-12

Initial Release

[unreleased]: https://github.com/Esri/Terraformer/compare/v1.0.12...HEAD
[1.0.12]: https://github.com/Esri/Terraformer/compare/v1.0.10...v1.0.12
[1.0.10]: https://github.com/Esri/Terraformer/compare/v1.0.9...v1.0.10
[1.0.9]: https://github.com/Esri/Terraformer/compare/v1.0.8...v1.0.9
[1.0.8]: https://github.com/Esri/Terraformer/compare/v1.0.7...v1.0.8
[1.0.7]: https://github.com/Esri/Terraformer/compare/v1.0.6...v1.0.7
[1.0.6]: https://github.com/Esri/Terraformer/compare/v1.0.5...v1.0.6
[1.0.5]: https://github.com/Esri/Terraformer/compare/v1.0.4...v1.0.5
[1.0.4]: https://github.com/Esri/Terraformer/compare/v1.0.3...v1.0.4
[1.0.3]: https://github.com/Esri/Terraformer/compare/v1.0.2...v1.0.3
[1.0.2]: https://github.com/Esri/Terraformer/compare/v1.0.1...v1.0.2
[1.0.1]: https://github.com/Esri/Terraformer/releases/tag/v1.0.1
